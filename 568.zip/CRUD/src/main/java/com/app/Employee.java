package com.app;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.sql.*;

public class Employee extends HttpServlet {

    // READ
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws IOException, ServletException {

        res.setContentType("text/html");
        PrintWriter out = res.getWriter();

        String username = req.getParameter("username");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
            	    "jdbc:mysql://localhost:3306/userdb", "root", "venisrirao@3426");

            String query = "SELECT salary FROM employee WHERE name=?";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, username);

            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                out.println("<h3>Salary: " + rs.getString(1) + "</h3>");
            } else {
                out.println("<h3>Employee not found</h3>");
            }

            con.close();

        } catch (Exception e) {
            e.printStackTrace(out);
        }
    }

    // CREATE / UPDATE / DELETE
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws IOException, ServletException {

        res.setContentType("text/html");
        PrintWriter out = res.getWriter();

        String method = req.getParameter("_method"); // put / delete
        String username = req.getParameter("username");
        String salary = req.getParameter("salary");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
            	    "jdbc:mysql://localhost:3306/userdb", "root", "venisrirao@3426");

            // 🔹 UPDATE
            if ("put".equalsIgnoreCase(method)) {

                String query = "UPDATE employee SET salary=? WHERE name=?";
                PreparedStatement pst = con.prepareStatement(query);

                pst.setString(1, salary);
                pst.setString(2, username);

                int rows = pst.executeUpdate();

                out.println(rows > 0
                        ? "<h3>Employee Updated Successfully</h3>"
                        : "<h3>Update Failed</h3>");

            }
            // 🔹 DELETE
            else if ("delete".equalsIgnoreCase(method)) {

                String query = "DELETE FROM employee WHERE name=?";
                PreparedStatement pst = con.prepareStatement(query);

                pst.setString(1, username);

                int rows = pst.executeUpdate();

                out.println(rows > 0
                        ? "<h3>Employee Deleted Successfully</h3>"
                        : "<h3>Delete Failed</h3>");
            }
            // 🔹 CREATE
            else {

                String query = "INSERT INTO employee (name, salary) VALUES (?, ?)";
                PreparedStatement pst = con.prepareStatement(query);

                pst.setString(1, username);
                pst.setString(2, salary);

                int rows = pst.executeUpdate();

                out.println(rows > 0
                        ? "<h3>Employee Created Successfully</h3>"
                        : "<h3>Error Creating Employee</h3>");
            }

            con.close();// write in finally

        } catch (Exception e) {
            e.printStackTrace(out);
        }
    }
}