package com.app;

import java.io.IOException;
import java.io.PrintWriter; 
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/WelcomeServlet")
public class WelcomeServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    public WelcomeServlet() {
        super();
    }

    //HANDLE POST (used by RequestDispatcher forward)
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");

        PrintWriter out = response.getWriter();

        String n = request.getParameter("userName");

        out.println("<h2 style='color:green'>Welcome " + n + "</h2>");
    }

    //OPTIONAL (for safety if GET is called)
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        doPost(request, response);
    }
}