package com.app;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Login
 */
@WebServlet(name = "Loginrd", description = "handle login", urlPatterns = { "/Loginrd" })
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        doPost(request, response);  //redirect GET to POST logic
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
	        throws ServletException, IOException {

	    response.setContentType("text/html");

	    String n = request.getParameter("userName");
	    String p = request.getParameter("userPass");

	    if (p != null && p.equals("servlet")) {
	    	RequestDispatcher rd = request.getRequestDispatcher("/WelcomeServlet");
	        rd.forward(request, response);

	    } else {

	        PrintWriter out = response.getWriter();
	        out.println("<h3 style='color:red'>Invalid Username or Password</h3>");

	        RequestDispatcher rd = request.getRequestDispatcher("/index.html");
	        rd.include(request, response);
	    }
	}

}
