// --------- A) Registration Validation ----------
function validateRegister() {
  let username = document.getElementById("regUsername").value;
  let email = document.getElementById("regEmail").value;
  let password = document.getElementById("regPassword").value;
  let confirm = document.getElementById("regConfirm").value;
  let msg = document.getElementById("regMsg");

  if (username === "" || username.length < 5) {
    msg.innerHTML = "Username must be at least 5 characters.";
    return false;
  }

  let emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailPattern.test(email)) {
    msg.innerHTML = "Enter a valid email address.";
    return false;
  }

  if (password === "" || password.length < 8) {
    msg.innerHTML = "Password must be at least 8 characters.";
    return false;
  }

  if (password !== confirm) {
    msg.innerHTML = "Passwords do not match.";
    return false;
  }

  // store email in dummy list so forgot password can find it
  if (!registeredEmails.includes(email)) {
    registeredEmails.push(email);
  }

  alert("Registration successful!");
  return true;
}

// --------- B) Forgot Password Validation ----------
let registeredEmails = ["test@gmail.com", "user@example.com"]; // dummy DB

function validateForgot() {
  let email = document.getElementById("forgotEmail").value;
  let msg = document.getElementById("forgotMsg");

  let emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  if (!emailPattern.test(email)) {
    msg.innerHTML = "Enter a valid email address.";
    return false;
  }

  if (!registeredEmails.includes(email)) {
    msg.innerHTML = "Email not associated with any account.";
    return false;
  }

  alert("Password reset link sent to your email!");
  return true;
}

// --------- C) Dynamic Content Loading ----------
function loadBook(page) {
  parent.frames['content'].location.href = page;
}
// --------- D) Login Validation ----------
let users = [
  { username: "admin1", email: "admin1@example.com", password: "password123" },
  { username: "student", email: "student@example.com", password: "student123" }
];
function validateLogin() {
  let uname = document.getElementById("loginUsername").value;
  let email = document.getElementById("loginEmail").value;
  let pwd = document.getElementById("loginPassword").value;
  let msg = document.getElementById("loginMsg");

  if ((uname === "" && email === "") || pwd === "") {
    msg.innerHTML = "Email or Username and Password cannot be empty.";
    return false;
  }

  let found = users.find(
    u =>
      ((uname && u.username === uname) || (email && u.email === email)) &&
      u.password === pwd
  );

  if (!found) {
    msg.innerHTML = "Invalid username or password.";
    return false;
  }

  alert("Login successful! Welcome " + uname);
  return true;
}
