// --------- A) Registration Validation ----------
function validateRegister() {
  let username = document.getElementById("regUsername").value;
  let email = document.getElementById("regEmail").value;
  let password = document.getElementById("regPassword").value;
  let confirm = document.getElementById("regConfirm").value;
  let msg = document.getElementById("regMsg");

  if (username === "" || username.length < 5) {
    msg.innerHTML = "Username must be at least 5 characters.";
    return false;
  }

  let emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailPattern.test(email)) {
    msg.innerHTML = "Enter a valid email address.";
    return false;
  }

  if (password === "" || password.length < 8) {
    msg.innerHTML = "Password must be at least 8 characters.";
    return false;
  }

  if (password !== confirm) {
    msg.innerHTML = "Passwords do not match.";
    return false;
  }

  // store email in dummy list so forgot password can find it
  if (!registeredEmails.includes(email)) {
    registeredEmails.push(email);
    localStorage.setItem('registeredEmails', JSON.stringify(registeredEmails));
  }

  // Add new user to users array
  const newUser = { username, email, password };
  users.push(newUser);
  localStorage.setItem('users', JSON.stringify(users));

  alert("Registration successful!");
  return true;
}

// --------- B) Forgot Password Validation ----------
let registeredEmails = JSON.parse(localStorage.getItem('registeredEmails')) || ["test@gmail.com", "user@example.com"]; // dummy DB

function validateForgot() {
  let email = document.getElementById("forgotEmail").value;
  let msg = document.getElementById("forgotMsg");

  let emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  if (!emailPattern.test(email)) {
    msg.innerHTML = "Enter a valid email address.";
    return false;
  }

  if (!registeredEmails.includes(email)) {
    msg.innerHTML = "Email not associated with any account.";
    return false;
  }

  alert("Password reset link sent to your email!");
  return true;
}

// --------- C) Dynamic Content Loading ----------
function loadBook(page) {
  parent.frames['content'].location.href = page;
}
// --------- D) Login Validation ----------
let users = JSON.parse(localStorage.getItem('users')) || [
  { username: "admin1", email: "admin1@example.com", password: "password123" },
  { username: "student", email: "student@example.com", password: "student123" }
];
function validateLogin() {
  let uname = document.getElementById("loginUsername").value;
  let email = document.getElementById("loginEmail").value;
  let pwd = document.getElementById("loginPassword").value;
  let msg = document.getElementById("loginMsg");

  if ((uname === "" && email === "") || pwd === "") {
    msg.innerHTML = "Email or Username and Password cannot be empty.";
    return false;
  }

  let found = users.find(
    u =>
      ((uname && u.username === uname) || (email && u.email === email)) &&
      u.password === pwd
  );

  if (!found) {
    msg.innerHTML = "Invalid username or password.";
    return false;
  }

  alert("Login successful! Welcome " + uname);
  return true;
}

// --------- E) Shopping Cart Functionality ----------
let cart = JSON.parse(localStorage.getItem('cart')) || [];

function addToCart(title, author, price, category) {
  if (!title) {
    // If no parameters, get from current page (book-details.html)
    title = document.getElementById("bookTitle").textContent;
    author = document.getElementById("bookAuthor").textContent;
    price = parseFloat(document.getElementById("bookPrice").textContent);
    category = document.getElementById("bookCategory").textContent;
  }

  const book = { title, author, price: parseFloat(price), category };
  cart.push(book);
  localStorage.setItem('cart', JSON.stringify(cart));
  alert("Book added to cart!");
}

function displayCart() {
  const cartItems = document.getElementById("cart-items");
  const totalPrice = document.getElementById("total-price");
  cartItems.innerHTML = "";
  let total = 0;

  cart.forEach((item, index) => {
    const itemDiv = document.createElement("div");
    itemDiv.className = "cart-item";
    itemDiv.innerHTML = `
      <h3>${item.title}</h3>
      <p>Author: ${item.author}</p>
      <p>Price: $${item.price}</p>
      <p>Category: ${item.category}</p>
      <button onclick="removeFromCart(${index})">Remove</button>
    `;
    cartItems.appendChild(itemDiv);
    total += item.price;
  });

  totalPrice.textContent = `Total: $${total.toFixed(2)}`;
}

function removeFromCart(index) {
  cart.splice(index, 1);
  localStorage.setItem('cart', JSON.stringify(cart));
  displayCart();
}

function clearCart() {
  cart = [];
  localStorage.removeItem('cart');
  displayCart();
}
